</div>
<footer class="main-footer d-flex justify-content-center">
    <strong>CopyRight&copy;2021 <a href="https://tehranftth.ir/">https://tehranftth.ir</a>.</strong>
</footer>
</div>
<script type="text/javascript" src="assets/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/adminlte.js"></script>
<script type="text/javascript" src="assets/js/custom.js"></script>
</body>
</html>