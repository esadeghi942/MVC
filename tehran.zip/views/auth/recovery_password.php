<?php
$titlepage = 'فیبر نوری تهران -  بازیابی رمز عبور';
$titlecard = 'بازیابی رمز عبور';
include 'views/auth/header.php';
?>
<p>کد ارسالی را وارد نمایید</p>
<form method="POST">
    <div class="form-group justify-content-center">
        <input placeholder="کد ارسالی" id="code" type="text"
               class="form-control"
               name="code" value="" required autofocus>
    </div>
    <div class="form-group row mb-0 justify-content-center">
        <button type="submit" class="btn btn-primary">
            ثبت
        </button>
    </div>
</form>
</div>
</div>
</div>
</div>
</div>

</body>
</html>