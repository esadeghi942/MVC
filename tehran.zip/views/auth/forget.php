<?php
$titlepage = 'فیبر نوری تهران -  فراموشی رمز عبور';
$titlecard = 'بازیابی رمز عبور';
include 'views/auth/header.php';
?>
<p>شماره تلفن خود را برای ارسال کد وارد کنید</p>
<form method="POST">
    <div class="form-group justify-content-center">
        <input placeholder="شماره تلفن" id="phone" type="text"
               class="form-control"
               name="phone" required autofocus>
    </div>
    <div class="form-group row mb-0 justify-content-center">
        <button type="submit" class="btn btn-primary">
            ارسال کد
        </button>
    </div>
</form>
</div>
</div>
</div>
</div>
</div>

</body>
</html>