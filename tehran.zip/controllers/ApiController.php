<?php

class ApiController
{
    public static function index(){}
	public static function v1($u){}

}