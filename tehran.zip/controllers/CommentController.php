<?php
namespace Controllers;
use Models\Comment;
use Systems\View;

class CommentController
{
    function index(){
        return View::make('user/comment');
    }

}