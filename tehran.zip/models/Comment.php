<?php
namespace Models;

class Comment extends BaseModel
{

}